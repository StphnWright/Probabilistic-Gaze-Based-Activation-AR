This package contains third-party software components governed by the license(s) indicated below:

Component Name: ThirdParty/SimpleJson

License Type: "MIT"

[SimpleJson License](https://github.com/Bunny83/SimpleJSON/blob/master/LICENSE.txt)