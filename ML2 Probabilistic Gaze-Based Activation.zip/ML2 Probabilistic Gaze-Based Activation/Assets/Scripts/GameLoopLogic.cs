using UnityEngine;

public class GameLoopLogic : MonoBehaviour
{
   public void ExitGame()
   {
      Application.Quit();
   }
}
